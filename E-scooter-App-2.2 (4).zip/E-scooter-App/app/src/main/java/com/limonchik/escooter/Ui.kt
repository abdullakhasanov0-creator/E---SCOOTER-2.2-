package com.limonchik.escooter

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

const val BOT_URL = "https://t.me/EScooterApp_bot"
const val CHANNEL_URL = "https://t.me/EscooterOfficial"

private fun f1(x: Double) = String.format(Locale.US, "%.1f", x)

private fun openUrl(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
}

@Composable
fun AppRoot(vm: ScooterVM) {
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf("") }
    var picker by remember { mutableStateOf(false) }
    var step by remember { mutableIntStateOf(if (!vm.onboarded) 1 else if (!vm.subShown) 2 else 0) }

    LaunchedEffect(vm.message) { vm.message?.let { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show(); vm.message = null } }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.all { it }) { picker = true; vm.startScan() } else { vm.message = "Нужны разрешения Bluetooth" }
    }
    val enableLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {}

    fun openPicker() {
        val need = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (!need.all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }) { permLauncher.launch(need); return }
        if (!vm.bluetoothOn) { enableLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)); return }
        picker = true; vm.startScan()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { Header(vm, onMenu = { dialog = it }) },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                listOf("🛴" to "Главная", "⚡" to "Скорость", "💡" to "Свет", "🩺" to "Диагностика", "⚙️" to "Настройки")
                    .forEachIndexed { i, (e, t) ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Text(e, fontSize = 20.sp) }, label = { Text(t, fontSize = 10.sp, maxLines = 1) })
                    }
            }
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeTab(vm, onConnect = ::openPicker, goLight = { tab = 2 })
                1 -> SpeedTab(vm)
                2 -> LightTab(vm)
                3 -> DiagTab(vm)
                else -> SettingsTab(vm, onDialog = { dialog = it })
            }
        }
    }

    if (picker) DevicePicker(vm, onClose = { picker = false; vm.stopScan() })
    when (dialog) {
        "about" -> AboutDialog { dialog = "" }
        "protocol" -> ProtocolDialog(vm) { dialog = "" }
        "profile" -> ProfileDialog(vm, first = false, onDone = { dialog = "" }, onCancel = { dialog = "" })
    }
    if (step == 1) ProfileDialog(vm, first = true, onDone = { step = if (!vm.subShown) 2 else 0 }, onCancel = {})
    if (step == 2) AlertDialog(
        onDismissRequest = {},
        title = { Text("Новости и обновления") },
        text = { Text("Подпишитесь на канал E-scooter App в Telegram — там новые версии и прошивки.") },
        confirmButton = { Button(onClick = { vm.markSubShown(); step = 0; openUrl(ctx, CHANNEL_URL) }) { Text("Подписаться") } },
        dismissButton = { TextButton(onClick = { vm.markSubShown(); step = 0 }) { Text("Позже") } },
    )
}

// ---------------------------------------------------------------- шапка

@Composable
fun Header(vm: ScooterVM, onMenu: (String) -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    val ok = vm.conn == ConnState.READY
    Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("E-scooter App", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(if (ok) Color(0xFF30D158) else Color(0xFF8E8E93)))
                Spacer(Modifier.width(8.dp))
                Text((if (ok) "Подключено" else "Не подключено") + " · " + vm.modelName(),
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp, maxLines = 1)
            }
        }
        Box {
            Box(Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surface).clickable { menu = true },
                contentAlignment = Alignment.Center) { Text("⋮", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Профиль и модель") }, onClick = { menu = false; onMenu("profile") })
                DropdownMenuItem(text = { Text("Протокол (hex)") }, onClick = { menu = false; onMenu("protocol") })
                DropdownMenuItem(text = { Text("Telegram-канал") }, onClick = { menu = false; openUrl(ctx, CHANNEL_URL) })
                DropdownMenuItem(text = { Text("Telegram-бот") }, onClick = { menu = false; openUrl(ctx, BOT_URL) })
                DropdownMenuItem(text = { Text("О приложении") }, onClick = { menu = false; onMenu("about") })
            }
        }
    }
}

// ---------------------------------------------------------------- общие элементы

@Composable
fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(MaterialTheme.colorScheme.surface).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        content()
    }
}

@Composable
fun Tile(emoji: String, title: String, sub: String, on: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val bg = if (on) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface
    Column(modifier.clip(RoundedCornerShape(24.dp)).background(bg).clickable(onClick = onClick).padding(16.dp)) {
        Text(emoji, fontSize = 28.sp)
        Spacer(Modifier.height(6.dp))
        Text(title, fontWeight = FontWeight.Bold)
        Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun SwitchRow(title: String, sub: String = "", checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (sub.isNotEmpty()) Text(sub, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun Chips(items: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items.forEachIndexed { i, s -> FilterChip(selected = selected == i, onClick = { onSelect(i) }, label = { Text(s) }) }
    }
}

@Composable
fun Gauge(value: Float, max: Float) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    val prim = MaterialTheme.colorScheme.primary
    Canvas(Modifier.size(220.dp)) {
        val stroke = 26.dp.toPx()
        val sz = Size(size.width - stroke, size.height - stroke)
        val tl = Offset(stroke / 2, stroke / 2)
        drawArc(track, 150f, 240f, false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
        drawArc(prim, 150f, 240f * (value / max).coerceIn(0f, 1f), false, tl, sz, style = Stroke(stroke, cap = StrokeCap.Round))
    }
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)) { content(); Spacer(Modifier.height(12.dp)) }
}

// ---------------------------------------------------------------- Главная

@Composable
fun HomeTab(vm: ScooterVM, onConnect: () -> Unit, goLight: () -> Unit) {
    val t = vm.tel
    val ok = vm.conn == ConnState.READY
    Page {
        Box(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF3A3A3C), Color(0xFF111114))))) {
            Button(onClick = { if (ok) vm.disconnect() else onConnect() }, modifier = Modifier.align(Alignment.TopEnd).padding(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0x66000000), contentColor = Color.White)) {
                Text(if (ok) "Отключить" else if (vm.conn == ConnState.CONNECTING) "Соединяю…" else "Подключить", fontWeight = FontWeight.Bold)
            }
            Column(Modifier.align(Alignment.BottomStart).padding(20.dp)) {
                Text(vm.modelName(), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Text("Контроллер KCQ · " + if (ok) "на связи" else "нет связи", color = Color(0xFFD0D0D5))
            }
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(MaterialTheme.colorScheme.surface).padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Box(contentAlignment = Alignment.Center) {
                Gauge((t.speedRaw / vm.speedDiv), vm.maxKmh.toFloat())
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(f1(t.speedRaw / vm.speedDiv.toDouble()), fontSize = 54.sp, fontWeight = FontWeight.Bold)
                    Text(if (t.miles) "миль/ч" else "км/ч", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat(if (t.battery >= 0) "${t.battery}%" else "–", "Заряд")
                Stat(if (t.valid) f1(t.tripRaw / vm.mileDiv.toDouble()) else "–", "Поездка")
                Stat(if (t.valid) f1(t.totalRaw / vm.mileDiv.toDouble()) else "–", "Всего")
            }
        }
        Text("Быстрое управление", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("💡", "Передний свет", if (t.headlight) "включён" else "выключен", t.headlight, Modifier.weight(1f)) { vm.setHeadlight(!t.headlight) }
            Tile("🔴", "Задний свет", if (t.taillight) "включён" else "выключен", t.taillight, Modifier.weight(1f)) { vm.setTaillight(!t.taillight) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Tile("🔒", "Замок", if (t.lock) "закрыт" else "открыт", t.lock, Modifier.weight(1f)) { vm.setLock(!t.lock) }
            Tile("⚡", "Стробоскоп", if (vm.strobeOn) "работает" else "настроить", vm.strobeOn, Modifier.weight(1f)) { goLight() }
        }
        Text("Автор: лимончик · @EScooterApp_bot", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    }
}

@Composable
fun Stat(v: String, label: String) = Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(v, fontSize = 24.sp, fontWeight = FontWeight.Bold)
    Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
}

// ---------------------------------------------------------------- Скорость / режимы

@Composable
fun SpeedTab(vm: ScooterVM) {
    val t = vm.tel
    Page {
        Section("Режим движения") {
            Chips(listOf("1 · Эко", "2 · Норма", "3 · Спорт"), (t.gear - 1).coerceAtLeast(-1)) { vm.setGear(it + 1) }
            Text("Сейчас: " + if (t.gear == 0) "нет данных" else "режим ${t.gear}", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Section("Лимиты скорости по режимам") {
            val names = listOf("Режим 1", "Режим 2", "Режим 3", "Скорость старта")
            val cur = listOf(t.oneSpeed, t.twoSpeed, t.threeSpeed, t.startSpeed)
            names.forEachIndexed { i, n ->
                Row { Text(n, Modifier.weight(1f)); Text("${vm.limits[i]} км/ч" + if (cur[i] >= 0) "  (сейчас ${cur[i]})" else "") }
                Slider(value = vm.limits[i].toFloat(), onValueChange = { v -> vm.limits = vm.limits.toMutableList().also { it[i] = v.toInt() } },
                    valueRange = 0f..vm.maxKmh.toFloat())
            }
            Button(onClick = { vm.applyLimits() }, modifier = Modifier.fillMaxWidth()) { Text("Применить лимиты") }
        }
        Section("Дополнительно") {
            SwitchRow("Круиз-контроль", "Удержание скорости", t.cruise) { vm.setCruise(it) }
            SwitchRow("Старт с толчка", "Выкл — старт с места", t.startMode) { vm.setStartMode(it) }
            SwitchRow("Мили вместо километров", "", t.miles) { vm.setMiles(it) }
        }
    }
}

// ---------------------------------------------------------------- Свет + стробоскоп

@Composable
fun LightTab(vm: ScooterVM) {
    val t = vm.tel
    Page {
        Section("Свет") {
            SwitchRow("Передний свет", "", t.headlight) { vm.setHeadlight(it) }
            SwitchRow("Задний свет", "", t.taillight) { vm.setTaillight(it) }
        }
        Section("Стробоскоп") {
            Text("Цель", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Chips(vm.targetNames(), vm.strobeTarget) { vm.setStrobeTarget(it) }
            Text("Узор", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Chips(vm.patternNames(), vm.strobePattern) { vm.setStrobePattern(it) }
            Row { Text("Интервал", Modifier.weight(1f)); Text("${vm.strobeMs} мс") }
            Slider(value = vm.strobeMs.toFloat(), onValueChange = { vm.setStrobeMs(it.toInt()) }, valueRange = 40f..600f)
            Button(onClick = { if (vm.strobeOn) vm.stopStrobe() else vm.startStrobe() }, modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = if (vm.strobeOn) Color(0xFFD32F2F) else MaterialTheme.colorScheme.primary)) {
                Text(if (vm.strobeOn) "Остановить (${vm.strobeCount})" else "Запустить стробоскоп")
            }
            Text("Стробоскоп шлёт много команд подряд. Только для закрытой территории.", fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ---------------------------------------------------------------- Диагностика

@Composable
fun DiagTab(vm: ScooterVM) {
    val ctx = LocalContext.current
    val t = vm.tel
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) try {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(vm.exportText().toByteArray()) }
            vm.message = "Лог сохранён"
        } catch (e: Exception) { vm.message = "Ошибка: ${e.message}" }
    }
    Page {
        Section("Состояние") {
            Text("Пакетов: RX ${vm.rx} · TX ${vm.tx}")
            Text("Заряд: " + if (t.battery >= 0) "${t.battery}%" else "нет данных")
            Text("Режим: ${if (t.gear == 0) "–" else t.gear} · Движение: ${if (t.drive) "да" else "нет"}")
            Text("Время в пути: ${t.rideSec / 60} мин ${t.rideSec % 60} с")
            Text("Версии прошивки: нет данных (команда запроса не найдена в APK)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Section("Ошибки") {
            if (t.faults.isEmpty()) Text(if (t.valid) "Ошибок нет ✅" else "Нет данных")
            else t.faults.forEach { Text("⚠️ $it", color = Color(0xFFFF453A)) }
        }
        Section("Последние пакеты по типам") {
            if (vm.lastRaw.isEmpty()) Text("—")
            vm.lastRaw.toSortedMap().forEach { (k, v) -> Text("%02X: %s".format(k, v), fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
        }
        Section("Лог") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { export.launch("escooter-log.txt") }) { Text("Экспорт .txt") }
                OutlinedButton(onClick = { vm.clearLog() }) { Text("Очистить") }
            }
            Column(Modifier.fillMaxWidth().heightIn(max = 320.dp).verticalScroll(rememberScrollState())) {
                vm.log.takeLast(120).forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
            }
        }
    }
}

// ---------------------------------------------------------------- Настройки

@Composable
fun SettingsTab(vm: ScooterVM, onDialog: (String) -> Unit) {
    var confirm by remember { mutableStateOf(false) }
    Page {
        Section("Тема") { Chips(listOf("Системная", "Светлая", "Тёмная"), vm.theme) { vm.setTheme(it) } }
        Section("Запись команд") {
            SwitchRow("Разрешить запись в самокат", "ALLOW_WRITE. По умолчанию выключено — команды только в логе",
                vm.allowWrite) { if (it) confirm = true else vm.setAllowWrite(false) }
        }
        Section("Дашборд") {
            Row { Text("Шкала спидометра", Modifier.weight(1f)); Text("${vm.maxKmh} км/ч") }
            Slider(value = vm.maxKmh.toFloat(), onValueChange = { vm.setMaxKmh(it.toInt()) }, valueRange = 20f..60f)
            Row { Text("Делитель скорости", Modifier.weight(1f)); Text(f1(vm.speedDiv.toDouble())) }
            Slider(value = vm.speedDiv, onValueChange = { vm.setSpeedDiv(Math.round(it).toFloat()) }, valueRange = 1f..100f)
            Row { Text("Делитель пробега", Modifier.weight(1f)); Text(f1(vm.mileDiv.toDouble())) }
            Slider(value = vm.mileDiv, onValueChange = { vm.setMileDiv(Math.round(it).toFloat()) }, valueRange = 1f..100f)
        }
        Section("Профиль") {
            Text("@${vm.username.ifBlank { "—" }} · ${vm.modelName()}")
            OutlinedButton(onClick = { onDialog("profile") }) { Text("Изменить") }
        }
        Text("Автор: лимончик", Modifier.fillMaxWidth(), textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false },
        title = { Text("Включить запись?") },
        text = { Text("Кадры собраны по декомпиляции KCQ Scooter и не проверены на всех контроллерах. Используйте на свой риск.") },
        confirmButton = { TextButton(onClick = { vm.setAllowWrite(true); confirm = false }) { Text("Включить") } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Отмена") } },
    )
}

// ---------------------------------------------------------------- Диалоги

@Composable
fun DevicePicker(vm: ScooterVM, onClose: () -> Unit) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (vm.scanning) "Поиск устройств…" else "Устройства") },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                items(vm.devices) { d ->
                    Column(Modifier.fillMaxWidth().clickable { vm.connect(d.address); onClose() }.padding(vertical = 10.dp)) {
                        Text(d.name.ifBlank { "Без имени" }, fontWeight = FontWeight.SemiBold)
                        Text("${d.address} · ${d.rssi} dBm", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    HorizontalDivider()
                }
            }
        },
        confirmButton = { TextButton(onClick = { vm.startScan() }) { Text("Обновить") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Закрыть") } },
    )
}

@Composable
fun ProfileDialog(vm: ScooterVM, first: Boolean, onDone: () -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    var user by remember { mutableStateOf(vm.username) }
    var model by remember { mutableStateOf(vm.modelId.ifBlank { "ninebot_max_g30" }) }
    var custom by remember { mutableStateOf(vm.customModel) }
    var open by remember { mutableStateOf(false) }
    val clean = user.trim().removePrefix("@")
    val valid = Regex("^[A-Za-z0-9_]{3,32}$").matches(clean) && (model != "other" || custom.isNotBlank())
    val label = if (model == "other") "Другой вариант" else vm.models.firstOrNull { it.id == model }?.name ?: model

    AlertDialog(
        onDismissRequest = { if (!first) onCancel() },
        title = { Text(if (first) "Регистрация" else "Профиль") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(value = user, onValueChange = { user = it }, singleLine = true,
                    label = { Text("Юзернейм Telegram") }, prefix = { Text("@") })
                Box {
                    OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) { Text(label) }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        vm.models.forEach { m -> DropdownMenuItem(text = { Text(m.name) }, onClick = { model = m.id; open = false }) }
                        DropdownMenuItem(text = { Text("Другой вариант") }, onClick = { model = "other"; open = false })
                    }
                }
                if (model == "other") OutlinedTextField(value = custom, onValueChange = { custom = it }, singleLine = true, label = { Text("Ваша модель") })
                if (first) Text("После нажатия откроется бот @EScooterApp_bot — отправьте ему сообщение (текст уже скопирован).",
                    fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            Button(enabled = valid, onClick = {
                vm.saveProfile(clean, model, custom.trim())
                if (first) {
                    val txt = "E-scooter App\nЮзернейм: @$clean\nМодель: ${vm.modelName()}"
                    (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("reg", txt))
                    val param = ("r_${model}_$clean").replace(Regex("[^A-Za-z0-9_-]"), "").take(64)
                    openUrl(ctx, "$BOT_URL?start=$param")
                }
                onDone()
            }) { Text(if (first) "Продолжить" else "Сохранить") }
        },
        dismissButton = if (first) null else ({ TextButton(onClick = onCancel) { Text("Отмена") } }),
    )
}

@Composable
fun AboutDialog(onClose: () -> Unit) = AlertDialog(
    onDismissRequest = onClose,
    title = { Text("E-scooter App 2.2") },
    text = { Text("Управление электросамокатами по BLE (контроллеры KCQ).\n\nАвтор: лимончик\nБот: @EScooterApp_bot\nКанал: t.me/EscooterOfficial") },
    confirmButton = { TextButton(onClick = onClose) { Text("OK") } },
)

@Composable
fun ProtocolDialog(vm: ScooterVM, onClose: () -> Unit) {
    val p = vm.proto
    val c = vm.ctrl()
    val sample = listOf(
        "фара вкл" to p.settingsFrame(c.copy(headlight = true)),
        "фара выкл" to p.settingsFrame(c.copy(headlight = false)),
        "задний вкл" to p.settingsFrame(c.copy(taillight = true)),
        "замок вкл" to p.settingsFrame(c.copy(lock = true)),
        "лимиты 15/25" to p.speed12Frame(15, 25),
        "лимит 3 / старт 35/5" to p.speed3Frame(35, 5),
    )
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Протокол") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Служба FFF0 · запись FFF6 · уведомления FFF7", fontSize = 12.sp)
                Text("Кадр: AA CC SIG B1 B2 XOR SUM EE\nXOR = B1^SIG, SUM = (B1+SIG+XOR)&FF\nSIG: A5 настройки, A7 лимиты 1/2, A8 лимит 3/старт", fontSize = 12.sp)
                Text("Примеры (по текущему состоянию):", fontWeight = FontWeight.SemiBold)
                sample.forEach { (n, f) -> Text("$n: ${f.hex()}", fontFamily = FontFamily.Monospace, fontSize = 11.sp) }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("OK") } },
    )
}
