package com.limonchik.escooter

import android.content.Context
import org.json.JSONObject
import java.util.UUID

/** Все константы протокола читаются из assets/protocol.json (извлечены из KCQ Scooter 1.5.4). */
class ProtocolConfig(j: JSONObject) {
    private val ble = j.getJSONObject("ble")
    val service: UUID = UUID.fromString(ble.getString("service"))
    val write: UUID = UUID.fromString(ble.getString("write"))
    val notify: UUID = UUID.fromString(ble.getString("notify"))
    val cccd: UUID = UUID.fromString(ble.getString("cccd"))

    private val wf = j.getJSONObject("write_frame")
    val head: IntArray = wf.getJSONArray("head").let { a -> IntArray(a.length()) { a.getInt(it) } }
    val tail: Int = wf.getInt("tail")
    val sigSettings: Int = wf.getInt("sig_settings")
    val sigSpeed12: Int = wf.getInt("sig_speed12")
    val sigSpeed3: Int = wf.getInt("sig_speed3")

    val s1: Map<String, Int> = bits(j.getJSONObject("s1_bits"))
    val s2: Map<String, Int> = bits(j.getJSONObject("s2_bits"))

    private val nf = j.getJSONObject("notify")
    val nHead: Int = nf.getInt("head")
    val nMain: Int = nf.getInt("main")
    val nPed: Int = nf.getInt("ped")
    val nSpeed: Int = nf.getInt("speed")

    val speedDiv: Double = j.getJSONObject("scales").getDouble("speed_div")
    val mileageDiv: Double = j.getJSONObject("scales").getDouble("mileage_div")

    private fun bits(o: JSONObject): Map<String, Int> =
        o.keys().asSequence().associateWith { o.getInt(it) }

    companion object {
        fun load(ctx: Context): ProtocolConfig =
            ProtocolConfig(JSONObject(ctx.assets.open("protocol.json").bufferedReader().use { it.readText() }))
    }
}

data class ScooterModel(val id: String, val brand: String, val name: String)

fun loadModels(ctx: Context): List<ScooterModel> {
    val arr = JSONObject(ctx.assets.open("models.json").bufferedReader().use { it.readText() }).getJSONArray("models")
    return (0 until arr.length()).map {
        val o = arr.getJSONObject(it)
        ScooterModel(o.getString("id"), o.getString("brand"), o.getString("name"))
    }
}

/** Настройки, которые уходят в самокат одним кадром (A5). */
data class Ctrl(
    val gearBit: Boolean,
    val cruise: Boolean,
    val startMode: Boolean,
    val headlight: Boolean,
    val taillight: Boolean,
    val miles: Boolean,
    val lock: Boolean,
    val thirdGear: Boolean,
    val thirdGearView: Boolean,
)

data class Telemetry(
    val valid: Boolean = false,
    val speedRaw: Int = 0,
    val totalRaw: Int = 0,
    val tripRaw: Int = 0,
    val battery: Int = -1,
    val faults: List<String> = emptyList(),
    val drive: Boolean = false,
    val thirdGearView: Boolean = false,
    val gear: Int = 0,
    val gearBit: Boolean = true,
    val cruise: Boolean = false,
    val startMode: Boolean = false,
    val headlight: Boolean = false,
    val taillight: Boolean = false,
    val miles: Boolean = false,
    val lock: Boolean = false,
    val rideSec: Int = 0,
    val oneSpeed: Int = -1,
    val twoSpeed: Int = -1,
    val threeSpeed: Int = -1,
    val startSpeed: Int = -1,
    val minMax: List<Int> = emptyList(),
)

fun ByteArray.hex(): String = joinToString(" ") { "%02X".format(it) }

class Protocol(private val c: ProtocolConfig) {

    /** HEAD0 HEAD1 SIG B1 B2 XOR SUM TAIL ; XOR = B1^SIG ; SUM = (B1+SIG+XOR)&0xFF */
    fun frame(sig: Int, b1: Int, b2: Int): ByteArray {
        val x = (b1 xor sig) and 0xFF
        val sum = (b1 + sig + x) and 0xFF
        return byteArrayOf(
            c.head[0].toByte(), c.head[1].toByte(), sig.toByte(),
            b1.toByte(), b2.toByte(), x.toByte(), sum.toByte(), c.tail.toByte(),
        )
    }

    fun settingsFrame(s: Ctrl): ByteArray {
        var b1 = 0
        fun put(k: String, v: Boolean) { if (v) b1 = b1 or (1 shl c.s1.getValue(k)) }
        put("gear", s.gearBit); put("cruise", s.cruise); put("start_mode", s.startMode)
        put("headlight", s.headlight); put("taillight", s.taillight); put("unit", s.miles); put("lock", s.lock)
        var b2 = 0
        fun put2(k: String, v: Boolean) { if (v) b2 = b2 or (1 shl c.s2.getValue(k)) }
        put2("third_gear", s.thirdGear); put2("third_gear_view", s.thirdGearView)
        return frame(c.sigSettings, b1, b2)
    }

    fun speed12Frame(one: Int, two: Int) = frame(c.sigSpeed12, one and 0xFF, two and 0xFF)
    fun speed3Frame(three: Int, start: Int) = frame(c.sigSpeed3, three and 0xFF, start and 0xFF)

    private fun u(d: ByteArray, i: Int) = d[i].toInt() and 0xFF
    private fun bit(v: Int, idx: Int) = ((v shr (7 - idx)) and 1) == 1   // idx — как в строке byteToBit (MSB первым)

    fun parse(d: ByteArray, t: Telemetry): Telemetry? {
        if (d.size < 3 || u(d, 0) != c.nHead) return null
        return when (u(d, 1)) {
            c.nMain -> if (d.size >= 14) parseMain(d, t) else null
            c.nPed -> if (d.size >= 9) t.copy(oneSpeed = u(d, 5), twoSpeed = u(d, 6), threeSpeed = u(d, 7), startSpeed = u(d, 8)) else null
            c.nSpeed -> if (d.size >= 14) t.copy(minMax = (8..13).map { u(d, it) }) else null
            else -> null
        }
    }

    private val faultNames = listOf(
        "Датчик Холла", "Силовой ключ (MOS)", "Тормоз", "Ручка газа",
        "Низкое напряжение", "Ошибка связи", "Высокое напряжение", "Нулевая калибровка",
    )

    private fun parseMain(d: ByteArray, t: Telemetry): Telemetry {
        val f9 = u(d, 9); val f10 = u(d, 10); val s = u(d, 11)
        val faults = faultNames.filterIndexed { i, _ -> bit(f9, i) }.toMutableList()
        if (bit(f10, 0)) faults += "Блокировка ротора"
        if (bit(f10, 6)) faults += "Температура"
        val g0 = bit(s, 0); val g1 = bit(s, 1)
        val gear = when { g0 && g1 -> 3; g0 -> 1; g1 -> 2; else -> 0 }
        return t.copy(
            valid = true,
            speedRaw = u(d, 2) or (u(d, 3) shl 8),
            totalRaw = u(d, 4) or (u(d, 5) shl 8),
            tripRaw = u(d, 6) or (u(d, 7) shl 8),
            battery = u(d, 8),
            faults = faults,
            drive = bit(f10, 2),
            thirdGearView = bit(f10, 5),
            gear = gear, gearBit = g0,
            cruise = bit(s, 2), startMode = bit(s, 3),
            headlight = bit(s, 4), taillight = bit(s, 5),
            miles = bit(s, 6), lock = bit(s, 7),
            rideSec = u(d, 12) or (u(d, 13) shl 8),
        )
    }
}
