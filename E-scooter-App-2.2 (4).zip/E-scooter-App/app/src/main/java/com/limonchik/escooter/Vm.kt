package com.limonchik.escooter

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScooterVM(app: Application) : AndroidViewModel(app) {
    private val p = app.getSharedPreferences("escooter", Context.MODE_PRIVATE)
    private val ui = Handler(Looper.getMainLooper())
    val cfg = ProtocolConfig.load(app)
    val models = loadModels(app)
    val proto = Protocol(cfg)

    // ---- состояние связи / данных ----
    var tel by mutableStateOf(Telemetry()); private set
    var conn by mutableStateOf(ConnState.IDLE); private set
    var devices by mutableStateOf<List<ScanItem>>(emptyList()); private set
    var scanning by mutableStateOf(false); private set
    val log = mutableStateListOf<String>()
    val lastRaw = mutableStateMapOf<Int, String>()
    var rx by mutableIntStateOf(0); private set
    var tx by mutableIntStateOf(0); private set
    var message by mutableStateOf<String?>(null)

    // ---- профиль / настройки (хранятся в SharedPreferences) ----
    var username by mutableStateOf(p.getString("username", "") ?: ""); private set
    var modelId by mutableStateOf(p.getString("model_id", "") ?: ""); private set
    var customModel by mutableStateOf(p.getString("custom_model", "") ?: ""); private set
    var onboarded by mutableStateOf(p.getBoolean("onboarded", false)); private set
    var subShown by mutableStateOf(p.getBoolean("sub_shown", false)); private set
    var theme by mutableIntStateOf(p.getInt("theme", 0)); private set
    var allowWrite by mutableStateOf(p.getBoolean("allow_write", BuildConfig.ALLOW_WRITE)); private set
    var speedDiv by mutableFloatStateOf(p.getFloat("speed_div", cfg.speedDiv.toFloat())); private set
    var mileDiv by mutableFloatStateOf(p.getFloat("mile_div", cfg.mileageDiv.toFloat())); private set
    var maxKmh by mutableIntStateOf(p.getInt("max_kmh", 50)); private set
    var strobeMs by mutableIntStateOf(p.getInt("strobe_ms", 120)); private set
    var strobePattern by mutableIntStateOf(p.getInt("strobe_pattern", 0)); private set
    var strobeTarget by mutableIntStateOf(p.getInt("strobe_target", 0)); private set
    var strobeOn by mutableStateOf(false); private set
    var strobeCount by mutableIntStateOf(0); private set
    var limits by mutableStateOf(listOf(15, 25, 35, 5))

    private val ble = BleManager(
        app, cfg,
        onState = { s -> conn = s; if (s != ConnState.READY && strobeOn) stopStrobe() ; addLog("Связь: $s") },
        onDevices = { devices = it },
        onData = ::onData,
        onLog = ::addLog,
    )

    val bluetoothOn get() = ble.enabled

    fun modelName(): String = when {
        modelId == "other" -> customModel.ifBlank { "Другая модель" }
        else -> models.firstOrNull { it.id == modelId }?.name ?: "Модель не выбрана"
    }

    // ---- профиль ----
    fun saveProfile(user: String, model: String, custom: String) {
        username = user; modelId = model; customModel = custom; onboarded = true
        p.edit().putString("username", user).putString("model_id", model)
            .putString("custom_model", custom).putBoolean("onboarded", true).apply()
    }
    fun markSubShown() { subShown = true; p.edit().putBoolean("sub_shown", true).apply() }
    fun resetProfile() {
        onboarded = false; subShown = false
        p.edit().putBoolean("onboarded", false).putBoolean("sub_shown", false).apply()
    }

    fun setTheme(v: Int) { theme = v; p.edit().putInt("theme", v).apply() }
    fun setAllowWrite(v: Boolean) { allowWrite = v; p.edit().putBoolean("allow_write", v).apply() }
    fun setSpeedDiv(v: Float) { speedDiv = v; p.edit().putFloat("speed_div", v).apply() }
    fun setMileDiv(v: Float) { mileDiv = v; p.edit().putFloat("mile_div", v).apply() }
    fun setMaxKmh(v: Int) { maxKmh = v; p.edit().putInt("max_kmh", v).apply() }
    fun setStrobeMs(v: Int) { strobeMs = v; p.edit().putInt("strobe_ms", v).apply() }
    fun setStrobePattern(v: Int) { strobePattern = v; p.edit().putInt("strobe_pattern", v).apply() }
    fun setStrobeTarget(v: Int) { strobeTarget = v; p.edit().putInt("strobe_target", v).apply() }

    // ---- BLE ----
    fun startScan() {
        if (!ble.enabled) { message = "Включите Bluetooth"; return }
        scanning = ble.startScan()
    }
    fun stopScan() { ble.stopScan(); scanning = false }
    fun connect(address: String) { stopScan(); ble.connect(address); p.edit().putString("last_dev", address).apply() }
    fun disconnect() { stopStrobe(); ble.disconnect() }

    private fun onData(d: ByteArray) {
        rx++
        addLog("RX ${d.hex()}")
        if (d.size >= 2) lastRaw[d[1].toInt() and 0xFF] = d.hex()
        proto.parse(d, tel)?.let { tel = it }
    }

    fun addLog(s: String) {
        val line = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date()) + "  " + s
        ui.post { log.add(line); while (log.size > 600) log.removeAt(0) }
    }
    fun clearLog() { log.clear() }
    fun exportText(): String = buildString {
        appendLine("E-scooter App 2.2 — лог (${modelName()}, @$username)")
        appendLine("Автор: лимончик")
        appendLine()
        log.forEach { appendLine(it) }
    }

    // ---- отправка ----
    private fun canWrite(quiet: Boolean): Boolean {
        if (!allowWrite) { if (!quiet) message = "Запись отключена (Настройки → Разрешить запись)"; return false }
        if (conn != ConnState.READY) { if (!quiet) message = "Нет подключения"; return false }
        return true
    }

    fun send(frame: ByteArray, what: String, quiet: Boolean = false): Boolean {
        if (!canWrite(quiet)) { if (!quiet) addLog("TX[dry] $what: ${frame.hex()}"); return false }
        val ok = ble.write(frame)
        tx++
        if (!quiet) addLog("TX $what: ${frame.hex()}" + if (ok) "" else " (ошибка записи)")
        return ok
    }

    fun ctrl() = Ctrl(
        gearBit = tel.gearBit, cruise = tel.cruise, startMode = tel.startMode,
        headlight = tel.headlight, taillight = tel.taillight, miles = tel.miles, lock = tel.lock,
        thirdGear = tel.gear == 3, thirdGearView = tel.thirdGearView,
    )

    private fun push(what: String, change: (Ctrl) -> Ctrl, opt: (Telemetry) -> Telemetry) {
        if (!tel.valid) { message = "Жду данные от самоката"; return }
        if (send(proto.settingsFrame(change(ctrl())), what)) tel = opt(tel)
    }

    fun setHeadlight(on: Boolean) = push("фара ${if (on) "вкл" else "выкл"}", { it.copy(headlight = on) }, { it.copy(headlight = on) })
    fun setTaillight(on: Boolean) = push("задний свет ${if (on) "вкл" else "выкл"}", { it.copy(taillight = on) }, { it.copy(taillight = on) })
    fun setLock(on: Boolean) = push("замок ${if (on) "вкл" else "выкл"}", { it.copy(lock = on) }, { it.copy(lock = on) })
    fun setCruise(on: Boolean) = push("круиз ${if (on) "вкл" else "выкл"}", { it.copy(cruise = on) }, { it.copy(cruise = on) })
    fun setStartMode(on: Boolean) = push("старт ${if (on) "с толчка" else "с места"}", { it.copy(startMode = on) }, { it.copy(startMode = on) })
    fun setMiles(on: Boolean) = push("единицы ${if (on) "mi" else "km"}", { it.copy(miles = on) }, { it.copy(miles = on) })
    fun setGear(g: Int) = push("режим $g", { it.copy(gearBit = g != 2, thirdGear = g == 3) }, { it.copy(gear = g, gearBit = g != 2) })

    fun applyLimits() {
        val l = limits
        val a = send(proto.speed12Frame(l[0], l[1]), "лимиты 1/2: ${l[0]}/${l[1]}")
        val b = send(proto.speed3Frame(l[2], l[3]), "лимит 3 / старт: ${l[2]}/${l[3]}")
        if (a && b) message = "Лимиты отправлены"
    }

    // ---- стробоскоп ----
    fun patternNames() = listOf("Ровный", "Двойной", "SOS")
    fun targetNames() = listOf("Фара", "Задний", "Оба", "Попеременно")

    private fun pattern(): List<Pair<Boolean, Long>> {
        val u = strobeMs.toLong()
        return when (strobePattern) {
            1 -> listOf(true to 50L, false to 50L, true to 50L, false to u * 4)
            2 -> buildList {
                repeat(3) { add(true to u); add(false to u) }; add(false to u * 2)
                repeat(3) { add(true to u * 3); add(false to u) }; add(false to u * 2)
                repeat(3) { add(true to u); add(false to u) }; add(false to u * 6)
            }
            else -> listOf(true to u, false to u)
        }
    }

    private fun step(c: Ctrl, on: Boolean): Ctrl = when (strobeTarget) {
        0 -> c.copy(headlight = on)
        1 -> c.copy(taillight = on)
        2 -> c.copy(headlight = on, taillight = on)
        else -> c.copy(headlight = on, taillight = !on)
    }

    private var strobeJob: Job? = null

    fun startStrobe() {
        if (strobeOn) return
        if (!tel.valid) { message = "Жду данные от самоката"; return }
        if (!canWrite(false)) return
        val base = ctrl()
        strobeOn = true; strobeCount = 0
        addLog("Стробоскоп: старт (${patternNames()[strobePattern]}, ${targetNames()[strobeTarget]}, ${strobeMs} мс)")
        strobeJob = viewModelScope.launch(Dispatchers.Default) {
            try {
                while (isActive) {
                    for ((on, ms) in pattern()) {
                        if (!send(proto.settingsFrame(step(base, on)), "strobe", quiet = true)) {
                            message = "Стробоскоп остановлен: ошибка записи"; return@launch
                        }
                        strobeCount++
                        delay(ms)
                    }
                }
            } finally {
                withContext(NonCancellable) {
                    send(proto.settingsFrame(base), "strobe-restore", quiet = true)
                    strobeOn = false
                }
            }
        }
    }

    fun stopStrobe() { strobeJob?.cancel(); strobeJob = null; strobeOn = false; addLog("Стробоскоп: стоп ($strobeCount кадров)") }

    override fun onCleared() { stopStrobe(); ble.close() }
}
