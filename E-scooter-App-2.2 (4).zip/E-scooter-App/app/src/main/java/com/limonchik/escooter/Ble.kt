package com.limonchik.escooter

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Handler
import android.os.Looper

enum class ConnState { IDLE, CONNECTING, READY, LOST }
data class ScanItem(val name: String, val address: String, val rssi: Int)

@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
class BleManager(
    private val ctx: Context,
    private val cfg: ProtocolConfig,
    private val onState: (ConnState) -> Unit,
    private val onDevices: (List<ScanItem>) -> Unit,
    private val onData: (ByteArray) -> Unit,
    private val onLog: (String) -> Unit,
) {
    private val ui = Handler(Looper.getMainLooper())
    private val adapter: BluetoothAdapter? =
        (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    private var gatt: BluetoothGatt? = null
    private var wChar: BluetoothGattCharacteristic? = null
    private val found = LinkedHashMap<String, ScanItem>()

    val enabled: Boolean get() = adapter?.isEnabled == true

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            val n = try { r.device.name } catch (e: Exception) { null } ?: r.scanRecord?.deviceName ?: ""
            found[r.device.address] = ScanItem(n, r.device.address, r.rssi)
            val list = found.values.sortedWith(compareBy({ it.name.isEmpty() }, { -it.rssi }))
            ui.post { onDevices(list) }
        }
    }

    fun startScan(): Boolean {
        val sc = adapter?.bluetoothLeScanner ?: return false
        found.clear(); ui.post { onDevices(emptyList()) }
        return try { sc.startScan(scanCb); true } catch (e: Exception) { onLog("scan: ${e.message}"); false }
    }

    fun stopScan() { try { adapter?.bluetoothLeScanner?.stopScan(scanCb) } catch (_: Exception) {} }

    fun connect(address: String) {
        stopScan(); close()
        val dev = adapter?.getRemoteDevice(address) ?: return
        ui.post { onState(ConnState.CONNECTING) }
        gatt = dev.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
    }

    fun close() {
        try { gatt?.disconnect(); gatt?.close() } catch (_: Exception) {}
        gatt = null; wChar = null
    }

    fun disconnect() { close(); ui.post { onState(ConnState.IDLE) } }

    /** WRITE без ответа, если характеристика поддерживает — нужно для стробоскопа. */
    @Synchronized
    fun write(data: ByteArray): Boolean {
        val g = gatt ?: return false
        val c = wChar ?: return false
        c.writeType = if (c.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
            BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        c.value = data
        return try { g.writeCharacteristic(c) } catch (e: Exception) { false }
    }

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) g.discoverServices()
            else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                try { g.close() } catch (_: Exception) {}
                if (gatt === g) { gatt = null; wChar = null }
                ui.post { onState(ConnState.LOST) }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val svc = g.getService(cfg.service)
            val w = svc?.getCharacteristic(cfg.write)
            val n = svc?.getCharacteristic(cfg.notify)
            if (svc == null || w == null || n == null) {
                ui.post { onLog("Сервис FFF0/FFF6/FFF7 не найден"); onState(ConnState.LOST) }
                return
            }
            wChar = w
            g.setCharacteristicNotification(n, true)
            val d = n.getDescriptor(cfg.cccd)
            if (d != null) { d.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE; g.writeDescriptor(d) }
            ui.post { onState(ConnState.READY) }
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val v = c.value ?: return
            ui.post { onData(v.copyOf()) }
        }
    }
}
