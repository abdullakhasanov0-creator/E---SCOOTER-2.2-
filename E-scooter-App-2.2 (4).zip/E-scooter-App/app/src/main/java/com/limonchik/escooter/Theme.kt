package com.limonchik.escooter

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Dark = darkColorScheme(
    primary = Color(0xFF4DA3FF), background = Color(0xFF000000), surface = Color(0xFF1C1C1E),
    surfaceVariant = Color(0xFF2C2C2E), onBackground = Color.White, onSurface = Color.White,
    onSurfaceVariant = Color(0xFF9A9AA0),
)
private val Light = lightColorScheme(
    primary = Color(0xFF0A6CFF), background = Color(0xFFF2F2F7), surface = Color.White,
    surfaceVariant = Color(0xFFE5E5EA), onBackground = Color(0xFF111111), onSurface = Color(0xFF111111),
    onSurfaceVariant = Color(0xFF6B6B70),
)

@Composable
fun EScooterTheme(dark: Boolean, content: @Composable () -> Unit) =
    MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
