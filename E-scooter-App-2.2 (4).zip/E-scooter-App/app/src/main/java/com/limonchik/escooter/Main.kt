package com.limonchik.escooter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.MaterialTheme
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val vm: ScooterVM = viewModel()
            val dark = when (vm.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
            EScooterTheme(dark) {
                Surface(color = MaterialTheme.colorScheme.background) { AppRoot(vm) }
            }
        }
    }
}
